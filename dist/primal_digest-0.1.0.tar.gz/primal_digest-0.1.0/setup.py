# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['primal_digest']

package_data = \
{'': ['*'], 'primal_digest': ['templates/*']}

install_requires = \
['Jinja2>=3.1.2,<4.0.0',
 'biopython>=1.80,<2.0',
 'diskcache>=5.4.0,<6.0.0',
 'kmer-tools==0.1.0',
 'numpy>=1.24,<2.0',
 'parasail>=1.3.3,<2.0.0',
 'primer3-py>=0.6.1,<0.7.0']

entry_points = \
{'console_scripts': ['primal-digest = primal_digest.main:main']}

setup_kwargs = {
    'name': 'primal-digest',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'ChrisKent',
    'author_email': 'chrisgkent@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
